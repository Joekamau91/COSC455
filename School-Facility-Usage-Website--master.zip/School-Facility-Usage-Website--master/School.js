// School CLass
var school = {street: "", sNumber:0, zipcode: 0, schoolName: "", county: "", phone: 0};

function addSchool(school, street, sNumber, zipcode, schoolName, phone){
	"use strict";
	 var x = new school(school, street, sNumber, zipcode, schoolName, phone)
	
}
function deleteSchool(school){
	"use strict";
	school.street =null;
	school.sNumber = null;
	school.zipcode = null;
	school. schoolName = null;
	school.county = null;
	school.phone = null;
}

	


