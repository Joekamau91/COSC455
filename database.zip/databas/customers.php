<html><head><title>Cars</title></head>
<body>
<table border=1>
<tr><th>ID</th><th>FNAME</th><th>LNAME</th><th>SSNO</th>
<th>PURCHASE</th></tr>
<?php
include 'db.inc.php';
// Connect to MySQL DBMS
if (!($connection = @ mysql_connect($hostName, $username,
  $password)))
  showerror();
// Use the cars database
if (!mysql_select_db($databaseName, $connection))
  showerror();
 
// Create SQL statement
$query = "SELECT * FROM CUSTOMERS";
// Execute SQL statement
if (!($result = @ mysql_query ($query, $connection)))
  showerror();
// Display results
while ($row = @ mysql_fetch_array($result))
  echo "<tr><td>{$row["id"]}</td>
<td>{$row["Fname"]}</td>
<td>{$row["Lname"]}</td>
<td>{$row["SocialSecurity"]}</td>
<td>{$row["purchase"]}</td></tr>";
?>
</table></body>
</html>