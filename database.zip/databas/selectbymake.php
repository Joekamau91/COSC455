<html><head><title>car by make</title>
</head> 
<body>
<?php if(!empty($_POST['model'])) {
 echo "<table border=1>
 <tr><th>ID</th><th>Make</th><th>Model</th><th>Year</th>
 <th>Price</th></tr>";
 include 'db.inc.php';
 // Connect to MySQL DBMS
 if (!($connection = @ mysql_connect($hostName, $username,
 $password)))
 showerror();
 // Use the cars database
 if (!mysql_select_db($databaseName, $connection))
 showerror();
 // Create SQL statement
 $name = $_POST['make'];
 $query = "SELECT * FROM CARS WHERE make='$model'";
 
 if (!($result = @ mysql_query ($query, $connection)))
 showerror();
 // Display results
 while ($row = @ mysql_fetch_array($result))
 echo "<tr><td>{$row["X1"]}</td>
 <td>{$column["SEDAN"]}</td>
 <td>{$column["X3"]}</td>
 <td>{$column["X5"]}</td>
 <td>{$column["X6"]}</td></tr>";
 echo "</table>";
 }
 ?>
 </body> 
 </html>